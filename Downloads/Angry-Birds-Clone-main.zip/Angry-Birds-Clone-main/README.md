# JavaScript Angry Bird Clone
Tutorial: [Open In YouTube](https://youtu.be/_r955zGxgFQ)
![Preview](preview.png)